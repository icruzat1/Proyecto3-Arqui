module ref_asic_program_rom(input wire [6:0] word_index_i, output reg [31:0] word_o);
always @* begin
case(word_index_i)
7'd0: word_o=32'h02a00137;
7'd1: word_o=32'h39310113;
7'd2: word_o=32'h00202623;
7'd3: word_o=32'h00100393;
7'd4: word_o=32'h00038413;
7'd5: word_o=32'hff9ff06f;
default: word_o=32'h00000013;
endcase
end
endmodule
