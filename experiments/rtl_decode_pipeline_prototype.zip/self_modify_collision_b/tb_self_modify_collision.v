
`timescale 1ns/1ps
module tb_self_modify_collision;
parameter integer MemoryVariant=0;
reg clk=0,rst_n=1;
reg [3:0] btn=0;
wire [3:0] leds; wire [6:0] seg1,seg2; wire miso;
asic_top #(.MemoryVariant(MemoryVariant)) dut(
  .clk_i(clk),.rst_ni(rst_n),.btn_i(btn),.leds_o(leds),.seg1_o(seg1),.seg2_o(seg2),
  .spi_sclk_i(1'b0),.spi_mosi_i(1'b0),.spi_cs_n_i(1'b1),.spi_miso_o(miso));
always #50 clk=~clk;
initial begin #7 rst_n=0; repeat(4) @(negedge clk); rst_n=1; end
initial begin repeat(3000) @(posedge clk); $fatal(1,"Directed timeout"); end

integer visits=0;
reg saw_collision=0;
always @(posedge clk) begin
  if(dut.core_rst_ni && dut.data_req && dut.data_we && dut.data_addr==12) begin
    if(!dut.instr_req || dut.instr_addr!=12) $fatal(1,"Missing actual read/write collision");
    saw_collision=1;
  end
  if(dut.core_rst_ni && dut.u_soc.u_core.rf_we && dut.u_soc.u_core.pc_id==12) begin
    if(dut.u_soc.u_core.rf_wdata !== (visits==0 ? 32'd1 : 32'd42))
      $fatal(1,"Wrong collision/future-refetch semantics visits=%0d value=%h",visits,dut.u_soc.u_core.rf_wdata);
    visits=visits+1;
  end
end
initial begin
  wait(visits==2);
  @(negedge clk);
  if(!saw_collision || dut.u_soc.u_core.u_rf.regs_q[8]!==1) $fatal(1,"Collision coverage missing");
  $display("PASS self_modify_collision variant=%0d first=1 refetch=42",MemoryVariant);
  $finish;
end


  // Golden copy is frozen before experiment; same stimuli and same ROM image.
  wire [3:0] golden_leds;
  wire [6:0] golden_seg1, golden_seg2;
  wire golden_miso;
  ref_asic_top #(.MemoryVariant(MemoryVariant)) golden (
    .clk_i(clk), .rst_ni(rst_n), .btn_i(btn), .leds_o(golden_leds),
    .seg1_o(golden_seg1), .seg2_o(golden_seg2), .spi_sclk_i(1'b0),
    .spi_mosi_i(1'b0), .spi_cs_n_i(1'b1), .spi_miso_o(golden_miso)
  );
  integer eq_cycles = 0, eq_commits = 0, eq_writes = 0, eq_loads = 0;
  integer eq_regs, eq_words;
  `define D dut.u_soc.u_core
  `define G golden.u_soc.u_core
  always @(posedge clk) begin
    if (dut.core_rst_ni && golden.core_rst_ni) begin
      if ({`D.stall,`D.rf_ready,`D.pc_set,`D.instr_valid_id,`D.pc_id,`D.rf_we,
           `D.instr_req_o,`D.instr_addr_o,`D.data_req_o,`D.data_we_o,`D.lsu_busy}
          !==
          {`G.stall,`G.rf_ready,`G.pc_set,`G.instr_valid_id,`G.pc_id,`G.rf_we,
           `G.instr_req_o,`G.instr_addr_o,`G.data_req_o,`G.data_we_o,`G.lsu_busy})
        $fatal(1,"DIFF protocol/cycle=%0d pc=%h golden_pc=%h",eq_cycles,`D.pc_id,`G.pc_id);
      if (`D.rf_we) begin
        if ({`D.rf_waddr,`D.rf_wdata} !== {`G.rf_waddr,`G.rf_wdata})
          $fatal(1,"DIFF commit cycle=%0d pc=%h got=%h expected=%h",eq_cycles,`D.pc_id,`D.rf_wdata,`G.rf_wdata);
        eq_commits = eq_commits + 1;
      end
      if (`D.data_req_o) begin
        if ({`D.data_addr_o,`D.data_be_o,`D.data_we_o} !== {`G.data_addr_o,`G.data_be_o,`G.data_we_o})
          $fatal(1,"DIFF request cycle=%0d pc=%h",eq_cycles,`D.pc_id);
        if (`D.data_we_o) begin
          if (`D.data_wdata_o !== `G.data_wdata_o)
            $fatal(1,"DIFF store cycle=%0d pc=%h",eq_cycles,`D.pc_id);
          eq_writes = eq_writes + 1;
        end else eq_loads = eq_loads + 1;
      end
      if (`D.pc_set && `D.pc_target !== `G.pc_target)
        $fatal(1,"DIFF control transfer cycle=%0d",eq_cycles);
      if (`D.instr_valid_id && `D.rf_ready) begin
        if ({`D.u_id.alu_operator,`D.u_id.alu_op_a_sel,`D.u_id.alu_op_b_sel,
             `D.u_id.imm_operand,`D.u_id.imm_target,`D.u_id.rf_we_dec,
             `D.u_id.rf_wd_sel,`D.u_id.is_branch,`D.u_id.is_jal,`D.u_id.is_jalr,
             `D.u_id.lsu_req_dec,`D.u_id.lsu_we_dec,`D.u_id.lsu_type_dec,`D.u_id.lsu_sign_dec}
            !==
            {`D.u_id.alu_operator_raw,`D.u_id.alu_op_a_sel_raw,`D.u_id.alu_op_b_sel_raw,
             `D.u_id.imm_operand_raw,`D.u_id.imm_target_raw,`D.u_id.rf_we_dec_raw,
             `D.u_id.rf_wd_sel_raw,`D.u_id.is_branch_raw,`D.u_id.is_jal_raw,`D.u_id.is_jalr_raw,
             `D.u_id.lsu_req_dec_raw,`D.u_id.lsu_we_dec_raw,`D.u_id.lsu_type_dec_raw,`D.u_id.lsu_sign_dec_raw})
          $fatal(1,"Retiming invariant violated cycle=%0d pc=%h",eq_cycles,`D.pc_id);
      end
    end
    #2;
    if (eq_cycles > 0) begin
      if ({dut.core_rst_ni,dut.mem_boot_done,dut.instr_rdata,leds,seg1,seg2,miso}
          !== {golden.core_rst_ni,golden.mem_boot_done,golden.instr_rdata,golden_leds,golden_seg1,golden_seg2,golden_miso})
        $fatal(1,"DIFF external/reset/fetch cycle=%0d",eq_cycles);
      for (eq_regs=1;eq_regs<16;eq_regs=eq_regs+1)
        if (`D.u_rf.regs_q[eq_regs] !== `G.u_rf.regs_q[eq_regs])
          $fatal(1,"DIFF RF x%0d cycle=%0d",eq_regs,eq_cycles);
    end
    eq_cycles = eq_cycles + 1;
  end
  generate
    if (MemoryVariant==0) begin
      always @(posedge clk) begin
        #3;
        for (eq_words=0;eq_words<16;eq_words=eq_words+1)
          if (dut.u_mem.gen_a.u_memory.ram_ff[eq_words] !== golden.u_mem.gen_a.u_memory.ram_ff[eq_words])
            $fatal(1,"DIFF RAM A word=%0d cycle=%0d",eq_words,eq_cycles);
      end
    end else begin
      always @(posedge clk) begin
        #3;
        for (eq_words=0;eq_words<144;eq_words=eq_words+1)
          if (dut.u_mem.gen_b.u_memory.mem_ff[eq_words] !== golden.u_mem.gen_b.u_memory.mem_ff[eq_words])
            $fatal(1,"DIFF RAM B word=%0d cycle=%0d",eq_words,eq_cycles);
      end
    end
  endgenerate
  final $display("COUNTS differential cycles=%0d commits=%0d stores=%0d loads=%0d",eq_cycles,eq_commits,eq_writes,eq_loads);
  `undef D
  `undef G
endmodule
