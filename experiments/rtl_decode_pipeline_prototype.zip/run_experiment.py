#!/usr/bin/env python3
"""Isolated cycle-by-cycle comparison; writes only this experiment directory."""
import hashlib
import json
import re
import runpy
import subprocess
import time
from pathlib import Path

ROOT = Path('/Users/ics/Desktop/Universidad/UAndes/Segundo Semestre - 2026/Arquitectura de Computadores/Proyecto 3')
OUT = Path(__file__).resolve().parent
SOURCES = [ROOT / x.strip() for x in (ROOT / 'config/rtl_asic.f').read_text().splitlines() if x.strip() and not x.startswith('#')]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot():
    before = json.loads((OUT/'source_sha256.json').read_text())
    for path, expected in before.items():
        assert sha(Path(path)) == expected, 'Production input changed: ' + path
    names = set()
    for src in SOURCES:
        names.update(re.findall(r'\bmodule\s+(\w+)', src.read_text()))
    pattern = re.compile(r'\b(?:'+'|'.join(sorted(names, key=len, reverse=True))+r')\b')
    originals = OUT/'original_sources'
    originals.mkdir(exist_ok=True)
    for src in SOURCES:
        target = originals / src.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(src.read_bytes())
    return before, pattern

CHECKER = r'''
  // Golden copy is frozen before experiment; same stimuli and same ROM image.
  wire [3:0] golden_leds;
  wire [6:0] golden_seg1, golden_seg2;
  wire golden_miso;
  ref_asic_top #(.MemoryVariant(MemoryVariant)) golden (
    .clk_i(clk), .rst_ni(rst_n), .btn_i(btn), .leds_o(golden_leds),
    .seg1_o(golden_seg1), .seg2_o(golden_seg2), .spi_sclk_i(SPI_SCLK),
    .spi_mosi_i(SPI_MOSI), .spi_cs_n_i(SPI_CS_N), .spi_miso_o(golden_miso)
  );
  integer eq_cycles = 0, eq_commits = 0, eq_writes = 0, eq_loads = 0;
  integer eq_regs, eq_words;
  `define D dut.u_soc.u_core
  `define G golden.u_soc.u_core
  always @(posedge clk) begin
    if (dut.core_rst_ni && golden.core_rst_ni) begin
      if ({`D.stall,`D.rf_ready,`D.pc_set,`D.instr_valid_id,`D.pc_id,`D.rf_we,
           `D.instr_req_o,`D.instr_addr_o,`D.data_req_o,`D.data_we_o,`D.lsu_busy}
          !==
          {`G.stall,`G.rf_ready,`G.pc_set,`G.instr_valid_id,`G.pc_id,`G.rf_we,
           `G.instr_req_o,`G.instr_addr_o,`G.data_req_o,`G.data_we_o,`G.lsu_busy})
        $fatal(1,"DIFF protocol/cycle=%0d pc=%h golden_pc=%h",eq_cycles,`D.pc_id,`G.pc_id);
      if (`D.rf_we) begin
        if ({`D.rf_waddr,`D.rf_wdata} !== {`G.rf_waddr,`G.rf_wdata})
          $fatal(1,"DIFF commit cycle=%0d pc=%h got=%h expected=%h",eq_cycles,`D.pc_id,`D.rf_wdata,`G.rf_wdata);
        eq_commits = eq_commits + 1;
      end
      if (`D.data_req_o) begin
        if ({`D.data_addr_o,`D.data_be_o,`D.data_we_o} !== {`G.data_addr_o,`G.data_be_o,`G.data_we_o})
          $fatal(1,"DIFF request cycle=%0d pc=%h",eq_cycles,`D.pc_id);
        if (`D.data_we_o) begin
          if (`D.data_wdata_o !== `G.data_wdata_o)
            $fatal(1,"DIFF store cycle=%0d pc=%h",eq_cycles,`D.pc_id);
          eq_writes = eq_writes + 1;
        end else eq_loads = eq_loads + 1;
      end
      if (`D.pc_set && `D.pc_target !== `G.pc_target)
        $fatal(1,"DIFF control transfer cycle=%0d",eq_cycles);
      if (`D.instr_valid_id && `D.rf_ready) begin
        if ({`D.u_id.alu_operator,`D.u_id.alu_op_a_sel,`D.u_id.alu_op_b_sel,
             `D.u_id.imm_operand,`D.u_id.imm_target,`D.u_id.rf_we_dec,
             `D.u_id.rf_wd_sel,`D.u_id.is_branch,`D.u_id.is_jal,`D.u_id.is_jalr,
             `D.u_id.lsu_req_dec,`D.u_id.lsu_we_dec,`D.u_id.lsu_type_dec,`D.u_id.lsu_sign_dec}
            !==
            {`D.u_id.alu_operator_raw,`D.u_id.alu_op_a_sel_raw,`D.u_id.alu_op_b_sel_raw,
             `D.u_id.imm_operand_raw,`D.u_id.imm_target_raw,`D.u_id.rf_we_dec_raw,
             `D.u_id.rf_wd_sel_raw,`D.u_id.is_branch_raw,`D.u_id.is_jal_raw,`D.u_id.is_jalr_raw,
             `D.u_id.lsu_req_dec_raw,`D.u_id.lsu_we_dec_raw,`D.u_id.lsu_type_dec_raw,`D.u_id.lsu_sign_dec_raw})
          $fatal(1,"Retiming invariant violated cycle=%0d pc=%h",eq_cycles,`D.pc_id);
      end
    end
    #2;
    if (eq_cycles > 0) begin
      if ({dut.core_rst_ni,dut.mem_boot_done,dut.instr_rdata,leds,seg1,seg2,miso}
          !== {golden.core_rst_ni,golden.mem_boot_done,golden.instr_rdata,golden_leds,golden_seg1,golden_seg2,golden_miso})
        $fatal(1,"DIFF external/reset/fetch cycle=%0d",eq_cycles);
      for (eq_regs=1;eq_regs<16;eq_regs=eq_regs+1)
        if (`D.u_rf.regs_q[eq_regs] !== `G.u_rf.regs_q[eq_regs])
          $fatal(1,"DIFF RF x%0d cycle=%0d",eq_regs,eq_cycles);
    end
    eq_cycles = eq_cycles + 1;
  end
  generate
    if (MemoryVariant==0) begin
      always @(posedge clk) begin
        #3;
        for (eq_words=0;eq_words<16;eq_words=eq_words+1)
          if (dut.u_mem.gen_a.u_memory.ram_ff[eq_words] !== golden.u_mem.gen_a.u_memory.ram_ff[eq_words])
            $fatal(1,"DIFF RAM A word=%0d cycle=%0d",eq_words,eq_cycles);
      end
    end else begin
      always @(posedge clk) begin
        #3;
        for (eq_words=0;eq_words<144;eq_words=eq_words+1)
          if (dut.u_mem.gen_b.u_memory.mem_ff[eq_words] !== golden.u_mem.gen_b.u_memory.mem_ff[eq_words])
            $fatal(1,"DIFF RAM B word=%0d cycle=%0d",eq_words,eq_cycles);
      end
    end
  endgenerate
  final $display("COUNTS differential cycles=%0d commits=%0d stores=%0d loads=%0d",eq_cycles,eq_commits,eq_writes,eq_loads);
  `undef D
  `undef G
'''

SELF_MOD_TB = r'''
`timescale 1ns/1ps
module tb_self_modify;
  parameter integer MemoryVariant=0;
  reg clk=0, rst_n=1;
  reg [3:0] btn=0;
  wire [3:0] leds;
  wire [6:0] seg1,seg2;
  wire miso;
  asic_top #(.MemoryVariant(MemoryVariant)) dut (
    .clk_i(clk),.rst_ni(rst_n),.btn_i(btn),.leds_o(leds),.seg1_o(seg1),.seg2_o(seg2),
    .spi_sclk_i(1'b0),.spi_mosi_i(1'b0),.spi_cs_n_i(1'b1),.spi_miso_o(miso));
  always #50 clk=~clk;
  integer epoch;
  initial begin
    #7 rst_n=0;
    for(epoch=0;epoch<2;epoch=epoch+1) begin
      repeat(4) @(negedge clk);
      rst_n=1;
      wait(dut.u_soc.u_core.u_rf.regs_q[8]===32'd99);
      @(negedge clk);
      if(dut.u_soc.u_core.u_rf.regs_q[7] !== (MemoryVariant ? 32'd42 : 32'd0))
        $fatal(1,"Wrong modified instruction result");
      $display("PASS self_modify variant=%0d epoch=%0d x7=%0d",MemoryVariant,epoch,dut.u_soc.u_core.u_rf.regs_q[7]);
      rst_n=0;
    end
    repeat(4) @(negedge clk);
    $finish;
  end
  initial begin repeat(3000) @(posedge clk); $fatal(1,"Self modifying timeout"); end
endmodule
'''

def run_case(name, tb_source, rom, pattern, variant):
    case = OUT / (name + '_' + 'ab'[variant])
    case.mkdir(exist_ok=True)
    rom_source = rom
    rom = case / 'asic_program_rom.v'
    rom.write_bytes(rom_source.read_bytes())
    gold = case / 'reference'
    gold.mkdir(exist_ok=True)
    candidate_sources = []
    reference_sources = []
    for src in SOURCES:
        original = OUT / 'original_sources' / src.relative_to(ROOT)
        used = rom if src.name == 'asic_program_rom.v' else original
        new = OUT/'espino_id_stage.v' if src.name == 'espino_id_stage.v' else used
        candidate_sources.append(new)
        renamed = gold/src.name
        renamed.write_text(pattern.sub(lambda m:'ref_'+m.group(),used.read_text()))
        reference_sources.append(renamed)
    spi = ('sclk','mosi','cs_n') if name=='top_io_real' else ("1'b0","1'b0","1'b1")
    checker = CHECKER
    for key,value in zip(('SPI_SCLK','SPI_MOSI','SPI_CS_N'),spi):
        checker = checker.replace(key,value)
    pos = tb_source.rfind('endmodule')
    assert pos >= 0
    tb=case/('tb_'+name+'.v')
    tb.write_text(tb_source[:pos]+checker+tb_source[pos:])
    (case/'inputs.json').write_text(json.dumps({
        'rom_source':str(rom_source),'rom_sha256':sha(rom),
        'testbench_original_sha256':hashlib.sha256(tb_source.encode()).hexdigest(),
        'testbench_with_checker_sha256':sha(tb),
        'candidate_id_sha256':sha(OUT/'espino_id_stage.v'),
        'reference_id_sha256':sha(OUT/'original_sources/rtl/espino_core/espino_id_stage.v'),
        'source_manifest':str(OUT/'source_sha256.json')},indent=2)+'\n')
    top='tb_'+name
    cmd=['/opt/homebrew/bin/iverilog','-g2012','-s',top,'-P',f'{top}.MemoryVariant={variant}','-o',str(case/'sim.vvp')]
    cmd.extend(map(str,[tb]+candidate_sources+reference_sources))
    start=time.monotonic()
    result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (case/'compile.log').write_text(result.stdout)
    assert result.returncode==0, result.stdout
    result=subprocess.run(['/opt/homebrew/bin/vvp',str(case/'sim.vvp')],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    (case/'run.log').write_text(result.stdout)
    record={'name':name,'variant':variant,'returncode':result.returncode,'seconds':round(time.monotonic()-start,3),'passes':[x for x in result.stdout.splitlines() if x.startswith(('PASS ','COUNTS '))]}
    print(json.dumps(record),flush=True)
    assert result.returncode==0, result.stdout
    return record

def main():
    before, pattern=snapshot()
    asm=['lui x2,0x02a00','addi x2,x2,0x393','sw x2,128(x0)','jal x0,target']
    asm.extend(['addi x0,x0,0']*(32-len(asm)))
    asm += ['target: addi x0,x0,0','addi x8,x0,99','done: jal x0,done']
    source=OUT/'self_modify.s'
    source.write_text('\n'.join(asm)+'\n')
    files=runpy.run_path(str(ROOT/'scripts/generate_asic_memory.py'))['generate'](ROOT,source)
    rom_dir=OUT/'self_modify_rom'
    rom_dir.mkdir(exist_ok=True)
    for name,data in files.items(): (rom_dir/name).write_bytes(data)
    cases=[
        ('top_io_real',(ROOT/'sim/asic_stage2/tb_top_io_real.v').read_text(),ROOT/'build/asic_stage2/diagnostic_rom/asic_program_rom.v'),
        ('full_game',(ROOT/'sim/asic_stage3/tb_full_game.v').read_text(),ROOT/'build/asic_full_game/firmware/asic_program_rom.v'),
        ('self_modify',SELF_MOD_TB,rom_dir/'asic_program_rom.v')]
    results=[]
    for name,tb,rom in cases:
        for variant in (0,1): results.append(run_case(name,tb,rom,pattern,variant))
    unchanged=all(sha(Path(path))==expected for path,expected in before.items())
    assert unchanged
    (OUT/'result.json').write_text(json.dumps({'production_unchanged':unchanged,'candidate_sha256':sha(OUT/'espino_id_stage.v'),'cases':results},indent=2)+'\n')
    print('PASS isolated prototype: production sources unchanged',flush=True)

if __name__=='__main__': main()
