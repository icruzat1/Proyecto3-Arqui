
`timescale 1ns/1ps
module tb_isa_directed;
parameter integer MemoryVariant=0;
reg clk=0,rst_n=1;
reg [3:0] btn=0;
wire [3:0] leds; wire [6:0] seg1,seg2; wire miso;
asic_top #(.MemoryVariant(MemoryVariant)) dut(
  .clk_i(clk),.rst_ni(rst_n),.btn_i(btn),.leds_o(leds),.seg1_o(seg1),.seg2_o(seg2),
  .spi_sclk_i(1'b0),.spi_mosi_i(1'b0),.spi_cs_n_i(1'b1),.spi_miso_o(miso));
always #50 clk=~clk;
initial begin #7 rst_n=0; repeat(4) @(negedge clk); rst_n=1; end
initial begin repeat(3000) @(posedge clk); $fatal(1,"Directed timeout"); end
integer checked=0;
always @(posedge clk) begin
if(dut.core_rst_ni && dut.u_soc.u_core.u_id.commit) begin
case(dut.u_soc.u_core.pc_id)
32'd136: $fatal(1,"Flushed instruction committed");
32'd152: $fatal(1,"Flushed instruction committed");
32'd168: $fatal(1,"Flushed instruction committed");
32'd184: $fatal(1,"Flushed instruction committed");
32'd200: $fatal(1,"Flushed instruction committed");
32'd216: $fatal(1,"Flushed instruction committed");
32'd232: $fatal(1,"Flushed instruction committed");
32'd240: $fatal(1,"Flushed instruction committed");
default: begin end
endcase
end
if(dut.core_rst_ni && dut.u_soc.u_core.rf_we) begin
case(dut.u_soc.u_core.pc_id)
32'd0: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd1,32'h00000200}) $fatal(1,"ISA result pc=0"); checked=checked+1; end
32'd4: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd2,32'h89abd000}) $fatal(1,"ISA result pc=4"); checked=checked+1; end
32'd8: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd2,32'h89abcdef}) $fatal(1,"ISA result pc=8"); checked=checked+1; end
32'd16: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd3,32'hffffffef}) $fatal(1,"ISA result pc=16"); checked=checked+1; end
32'd20: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd4,32'h000000cd}) $fatal(1,"ISA result pc=20"); checked=checked+1; end
32'd24: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd5,32'hffff89ab}) $fatal(1,"ISA result pc=24"); checked=checked+1; end
32'd28: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd6,32'h0000cdef}) $fatal(1,"ISA result pc=28"); checked=checked+1; end
32'd32: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd7,32'h89abcdef}) $fatal(1,"ISA result pc=32"); checked=checked+1; end
32'd36: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd8,32'h0000005a}) $fatal(1,"ISA result pc=36"); checked=checked+1; end
32'd48: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd9,32'h005a5aef}) $fatal(1,"ISA result pc=48"); checked=checked+1; end
32'd52: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd3,32'hfffffff9}) $fatal(1,"ISA result pc=52"); checked=checked+1; end
32'd56: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd10,32'h00000053}) $fatal(1,"ISA result pc=56"); checked=checked+1; end
32'd60: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd11,32'h00000061}) $fatal(1,"ISA result pc=60"); checked=checked+1; end
32'd64: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd12,32'h00000001}) $fatal(1,"ISA result pc=64"); checked=checked+1; end
32'd68: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd13,32'h00000000}) $fatal(1,"ISA result pc=68"); checked=checked+1; end
32'd72: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'hffffffa3}) $fatal(1,"ISA result pc=72"); checked=checked+1; end
32'd76: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd15,32'hfffffffb}) $fatal(1,"ISA result pc=76"); checked=checked+1; end
32'd80: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd4,32'h00000058}) $fatal(1,"ISA result pc=80"); checked=checked+1; end
32'd84: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd5,32'h0000005b}) $fatal(1,"ISA result pc=84"); checked=checked+1; end
32'd88: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd6,32'hfffffffa}) $fatal(1,"ISA result pc=88"); checked=checked+1; end
32'd92: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd7,32'hfffffffa}) $fatal(1,"ISA result pc=92"); checked=checked+1; end
32'd96: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd4,32'h00000001}) $fatal(1,"ISA result pc=96"); checked=checked+1; end
32'd100: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd5,32'h00000000}) $fatal(1,"ISA result pc=100"); checked=checked+1; end
32'd104: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd6,32'hffffffac}) $fatal(1,"ISA result pc=104"); checked=checked+1; end
32'd108: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd7,32'hfffffffd}) $fatal(1,"ISA result pc=108"); checked=checked+1; end
32'd112: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd9,32'h000000f9}) $fatal(1,"ISA result pc=112"); checked=checked+1; end
32'd116: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd10,32'h0000005c}) $fatal(1,"ISA result pc=116"); checked=checked+1; end
32'd120: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd11,32'hfffffffb}) $fatal(1,"ISA result pc=120"); checked=checked+1; end
32'd124: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd12,32'h000003fb}) $fatal(1,"ISA result pc=124"); checked=checked+1; end
32'd128: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd9,32'h00001080}) $fatal(1,"ISA result pc=128"); checked=checked+1; end
32'd144: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'h00000010}) $fatal(1,"ISA result pc=144"); checked=checked+1; end
32'd160: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'h00000011}) $fatal(1,"ISA result pc=160"); checked=checked+1; end
32'd176: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'h00000014}) $fatal(1,"ISA result pc=176"); checked=checked+1; end
32'd192: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'h00000015}) $fatal(1,"ISA result pc=192"); checked=checked+1; end
32'd208: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'h00000016}) $fatal(1,"ISA result pc=208"); checked=checked+1; end
32'd224: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd14,32'h00000017}) $fatal(1,"ISA result pc=224"); checked=checked+1; end
32'd228: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd10,32'h000000e8}) $fatal(1,"ISA result pc=228"); checked=checked+1; end
32'd236: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd11,32'h000000f0}) $fatal(1,"ISA result pc=236"); checked=checked+1; end
32'd256: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd15,32'h0000007b}) $fatal(1,"ISA result pc=256"); checked=checked+1; end
default: begin end
endcase
end
end
initial begin wait(dut.u_soc.u_core.u_rf.regs_q[15]===32'd123); @(negedge clk); if(checked!=39) $fatal(1,"ISA missing checks %0d",checked); $display("PASS isa_directed variant=%0d checks=%0d",MemoryVariant,checked); $finish; end

  // Golden copy is frozen before experiment; same stimuli and same ROM image.
  wire [3:0] golden_leds;
  wire [6:0] golden_seg1, golden_seg2;
  wire golden_miso;
  ref_asic_top #(.MemoryVariant(MemoryVariant)) golden (
    .clk_i(clk), .rst_ni(rst_n), .btn_i(btn), .leds_o(golden_leds),
    .seg1_o(golden_seg1), .seg2_o(golden_seg2), .spi_sclk_i(1'b0),
    .spi_mosi_i(1'b0), .spi_cs_n_i(1'b1), .spi_miso_o(golden_miso)
  );
  integer eq_cycles = 0, eq_commits = 0, eq_writes = 0, eq_loads = 0;
  integer eq_regs, eq_words;
  `define D dut.u_soc.u_core
  `define G golden.u_soc.u_core
  always @(posedge clk) begin
    if (dut.core_rst_ni && golden.core_rst_ni) begin
      if ({`D.stall,`D.rf_ready,`D.pc_set,`D.instr_valid_id,`D.pc_id,`D.rf_we,
           `D.instr_req_o,`D.instr_addr_o,`D.data_req_o,`D.data_we_o,`D.lsu_busy}
          !==
          {`G.stall,`G.rf_ready,`G.pc_set,`G.instr_valid_id,`G.pc_id,`G.rf_we,
           `G.instr_req_o,`G.instr_addr_o,`G.data_req_o,`G.data_we_o,`G.lsu_busy})
        $fatal(1,"DIFF protocol/cycle=%0d pc=%h golden_pc=%h",eq_cycles,`D.pc_id,`G.pc_id);
      if (`D.rf_we) begin
        if ({`D.rf_waddr,`D.rf_wdata} !== {`G.rf_waddr,`G.rf_wdata})
          $fatal(1,"DIFF commit cycle=%0d pc=%h got=%h expected=%h",eq_cycles,`D.pc_id,`D.rf_wdata,`G.rf_wdata);
        eq_commits = eq_commits + 1;
      end
      if (`D.data_req_o) begin
        if ({`D.data_addr_o,`D.data_be_o,`D.data_we_o} !== {`G.data_addr_o,`G.data_be_o,`G.data_we_o})
          $fatal(1,"DIFF request cycle=%0d pc=%h",eq_cycles,`D.pc_id);
        if (`D.data_we_o) begin
          if (`D.data_wdata_o !== `G.data_wdata_o)
            $fatal(1,"DIFF store cycle=%0d pc=%h",eq_cycles,`D.pc_id);
          eq_writes = eq_writes + 1;
        end else eq_loads = eq_loads + 1;
      end
      if (`D.pc_set && `D.pc_target !== `G.pc_target)
        $fatal(1,"DIFF control transfer cycle=%0d",eq_cycles);
      if (`D.instr_valid_id && `D.rf_ready) begin
        if ({`D.u_id.alu_operator,`D.u_id.alu_op_a_sel,`D.u_id.alu_op_b_sel,
             `D.u_id.imm_operand,`D.u_id.imm_target,`D.u_id.rf_we_dec,
             `D.u_id.rf_wd_sel,`D.u_id.is_branch,`D.u_id.is_jal,`D.u_id.is_jalr,
             `D.u_id.lsu_req_dec,`D.u_id.lsu_we_dec,`D.u_id.lsu_type_dec,`D.u_id.lsu_sign_dec}
            !==
            {`D.u_id.alu_operator_raw,`D.u_id.alu_op_a_sel_raw,`D.u_id.alu_op_b_sel_raw,
             `D.u_id.imm_operand_raw,`D.u_id.imm_target_raw,`D.u_id.rf_we_dec_raw,
             `D.u_id.rf_wd_sel_raw,`D.u_id.is_branch_raw,`D.u_id.is_jal_raw,`D.u_id.is_jalr_raw,
             `D.u_id.lsu_req_dec_raw,`D.u_id.lsu_we_dec_raw,`D.u_id.lsu_type_dec_raw,`D.u_id.lsu_sign_dec_raw})
          $fatal(1,"Retiming invariant violated cycle=%0d pc=%h",eq_cycles,`D.pc_id);
      end
    end
    #2;
    if (eq_cycles > 0) begin
      if ({dut.core_rst_ni,dut.mem_boot_done,dut.instr_rdata,leds,seg1,seg2,miso}
          !== {golden.core_rst_ni,golden.mem_boot_done,golden.instr_rdata,golden_leds,golden_seg1,golden_seg2,golden_miso})
        $fatal(1,"DIFF external/reset/fetch cycle=%0d",eq_cycles);
      for (eq_regs=1;eq_regs<16;eq_regs=eq_regs+1)
        if (`D.u_rf.regs_q[eq_regs] !== `G.u_rf.regs_q[eq_regs])
          $fatal(1,"DIFF RF x%0d cycle=%0d",eq_regs,eq_cycles);
    end
    eq_cycles = eq_cycles + 1;
  end
  generate
    if (MemoryVariant==0) begin
      always @(posedge clk) begin
        #3;
        for (eq_words=0;eq_words<16;eq_words=eq_words+1)
          if (dut.u_mem.gen_a.u_memory.ram_ff[eq_words] !== golden.u_mem.gen_a.u_memory.ram_ff[eq_words])
            $fatal(1,"DIFF RAM A word=%0d cycle=%0d",eq_words,eq_cycles);
      end
    end else begin
      always @(posedge clk) begin
        #3;
        for (eq_words=0;eq_words<144;eq_words=eq_words+1)
          if (dut.u_mem.gen_b.u_memory.mem_ff[eq_words] !== golden.u_mem.gen_b.u_memory.mem_ff[eq_words])
            $fatal(1,"DIFF RAM B word=%0d cycle=%0d",eq_words,eq_cycles);
      end
    end
  endgenerate
  final $display("COUNTS differential cycles=%0d commits=%0d stores=%0d loads=%0d",eq_cycles,eq_commits,eq_writes,eq_loads);
  `undef D
  `undef G
endmodule
