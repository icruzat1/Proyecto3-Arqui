#!/usr/bin/env python3
"""Extra directed ISA/collision coverage, using the same differential checker."""
import json
from pathlib import Path
from run_experiment import OUT, snapshot, run_case, sha

def i(op,rd,rs1,imm,funct=0): return ((imm & 4095)<<20)|(rs1<<15)|(funct<<12)|(rd<<7)|op
def r(rd,rs1,rs2,funct=0,f7=0): return (f7<<25)|(rs2<<20)|(rs1<<15)|(funct<<12)|(rd<<7)|0x33
def s(rs1,rs2,off,funct=2): return (((off>>5)&127)<<25)|(rs2<<20)|(rs1<<15)|(funct<<12)|((off&31)<<7)|0x23
def b(rs1,rs2,off,funct): return (((off>>12)&1)<<31)|(((off>>5)&63)<<25)|(rs2<<20)|(rs1<<15)|(funct<<12)|(((off>>1)&15)<<8)|(((off>>11)&1)<<7)|0x63
def j(rd,off): return (((off>>20)&1)<<31)|(((off>>1)&1023)<<21)|(((off>>11)&1)<<20)|(((off>>12)&255)<<12)|(rd<<7)|0x6f

def rom_for(name,words):
    assert len(words)<=128
    dest=OUT/(name+'_rom.v')
    text='module asic_program_rom(input wire [6:0] word_index_i, output reg [31:0] word_o);\nalways @* begin\ncase(word_index_i)\n'
    text+=''.join("7'd%d: word_o=32'h%08x;\n"%(a,w) for a,w in enumerate(words))
    text+="default: word_o=32'h00000013;\nendcase\nend\nendmodule\n"
    dest.write_text(text)
    return dest

TOP=r'''
`timescale 1ns/1ps
module tb_NAME;
parameter integer MemoryVariant=0;
reg clk=0,rst_n=1;
reg [3:0] btn=0;
wire [3:0] leds; wire [6:0] seg1,seg2; wire miso;
asic_top #(.MemoryVariant(MemoryVariant)) dut(
  .clk_i(clk),.rst_ni(rst_n),.btn_i(btn),.leds_o(leds),.seg1_o(seg1),.seg2_o(seg2),
  .spi_sclk_i(1'b0),.spi_mosi_i(1'b0),.spi_cs_n_i(1'b1),.spi_miso_o(miso));
always #50 clk=~clk;
initial begin #7 rst_n=0; repeat(4) @(negedge clk); rst_n=1; end
initial begin repeat(3000) @(posedge clk); $fatal(1,"Directed timeout"); end
BODY
endmodule
'''

def isa_case():
    words=[]; expectations=[]; forbidden=[]
    def emit(word,rd=None,value=None):
        if rd is not None: expectations.append((4*len(words),rd,value&0xffffffff))
        words.append(word)
    emit(i(0x13,1,0,512),1,512)
    emit((0x89abd<<12)|(2<<7)|0x37,2,0x89abd000)
    emit(i(0x13,2,2,-529),2,0x89abcdef)
    emit(s(1,2,0))
    for rd,off,f,value in [(3,0,0,0xffffffef),(4,1,4,0xcd),(5,2,1,0xffff89ab),(6,0,5,0xcdef),(7,0,2,0x89abcdef)]:
        emit(i(3,rd,1,off,f),rd,value)
    emit(i(0x13,8,0,90),8,90)
    emit(s(1,8,1,0))
    emit(s(1,8,2,1))
    emit(i(3,9,1,0,2),9,0x005a5aef)
    emit(i(0x13,3,0,-7),3,-7)
    for rd,rs1,rs2,f,f7,value in [
        (10,3,8,0,0,83),(11,8,3,0,32,97),
        (12,3,8,2,0,1),(13,3,8,3,0,0),
        (14,3,8,4,0,0xffffffa3),(15,3,8,6,0,0xfffffffb),(4,3,8,7,0,0x58),
        # Production ALU explicitly disables shifts: preserve its ADD fallback.
        # These expectations are NOT architectural RISC-V shift semantics.
        (5,8,12,1,0,91),(6,3,12,5,0,-6),(7,3,12,5,32,-6)]:
        emit(r(rd,rs1,rs2,f,f7),rd,value)
    for rd,rs1,imm,f,value in [(4,3,0,2,1),(5,3,0,3,0),(6,3,0x55,4,0xffffffac),
        (7,3,4,6,0xfffffffd),(9,3,0xff,7,0xf9),(10,8,2,1,92),
        (11,3,2,5,-5),(12,3,1026,5,1019)]:
        emit(i(0x13,rd,rs1,imm,f),rd,value)
    pc=len(words)*4
    emit((1<<12)|(9<<7)|0x17,9,pc+4096)
    # Every branch predicate both taken and not taken; wrong-path sentinels.
    for f,taken1,taken2 in [(0,8,8),(1,3,8),(4,3,8),(5,8,3),(6,8,3),(7,3,8)]:
        emit(b(taken1,taken2,8,f))
        forbidden.append(len(words)*4)
        emit(i(0x13,15,0,-1))
        # Invert condition with explicit operand pair (including EQ/NE).
        falsepair=(3,8) if f==0 else ((8,8) if f==1 else (taken2,taken1))
        emit(b(falsepair[0],falsepair[1],8,f))
        emit(i(0x13,14,0,f+16),14,f+16)
    pc=len(words)*4
    emit(j(10,8),10,pc+4)
    forbidden.append(len(words)*4); emit(i(0x13,15,0,-1))
    pc=len(words)*4
    # JALR low bit clearing and link, next sequential instruction is flushed.
    emit(i(0x67,11,0,pc+9),11,pc+4)
    forbidden.append(len(words)*4); emit(i(0x13,15,0,-1))
    emit(0x0000000f) # FENCE implemented no-op
    emit(0x00000073) # SYSTEM funct3=0 implemented no-op
    emit(0xffffffff) # illegal opcode: preserve existing inert behavior
    emit(i(0x13,15,0,123),15,123)
    emit(j(0,0))
    checks=[]
    for pc,rd,value in expectations:
        checks.append("32'd%d: begin if ({dut.u_soc.u_core.rf_waddr,dut.u_soc.u_core.rf_wdata} !== {4'd%d,32'h%08x}) $fatal(1,\"ISA result pc=%d\"); checked=checked+1; end"%(pc,rd,value,pc))
    body='integer checked=0;\nalways @(posedge clk) begin\nif(dut.core_rst_ni && dut.u_soc.u_core.u_id.commit) begin\ncase(dut.u_soc.u_core.pc_id)\n'
    body+=''.join("32'd%d: $fatal(1,\"Flushed instruction committed\");\n"%pc for pc in forbidden)
    body+='default: begin end\nendcase\nend\nif(dut.core_rst_ni && dut.u_soc.u_core.rf_we) begin\ncase(dut.u_soc.u_core.pc_id)\n'+'\n'.join(checks)+'\ndefault: begin end\nendcase\nend\nend\n'
    body+='initial begin wait(dut.u_soc.u_core.u_rf.regs_q[15]===32\'d123); @(negedge clk); if(checked!=%d) $fatal(1,"ISA missing checks %%0d",checked); $display("PASS isa_directed variant=%%0d checks=%%0d",MemoryVariant,checked); $finish; end'%len(expectations)
    (OUT/'isa_expected.json').write_text(json.dumps({'words':len(words),'expected_rf_writes':expectations,'forbidden_pc':forbidden},indent=2)+'\n')
    return TOP.replace('NAME','isa_directed').replace('BODY',body),rom_for('isa_directed',words)

def collision_case():
    # At the store edge, fetch of PC12 samples the pre-write instruction.
    # On the second visit after the jump, that instruction must be modified.
    words=[(0x02a00<<12)|(2<<7)|0x37,i(0x13,2,2,0x393),s(0,2,12),i(0x13,7,0,1),i(0x13,8,7,0),j(0,-8)]
    body=r'''
integer visits=0;
reg saw_collision=0;
always @(posedge clk) begin
  if(dut.core_rst_ni && dut.data_req && dut.data_we && dut.data_addr==12) begin
    if(!dut.instr_req || dut.instr_addr!=12) $fatal(1,"Missing actual read/write collision");
    saw_collision=1;
  end
  if(dut.core_rst_ni && dut.u_soc.u_core.rf_we && dut.u_soc.u_core.pc_id==12) begin
    if(dut.u_soc.u_core.rf_wdata !== (visits==0 ? 32'd1 : 32'd42))
      $fatal(1,"Wrong collision/future-refetch semantics visits=%0d value=%h",visits,dut.u_soc.u_core.rf_wdata);
    visits=visits+1;
  end
end
initial begin
  wait(visits==2);
  @(negedge clk);
  if(!saw_collision || dut.u_soc.u_core.u_rf.regs_q[8]!==1) $fatal(1,"Collision coverage missing");
  $display("PASS self_modify_collision variant=%0d first=1 refetch=42",MemoryVariant);
  $finish;
end
'''
    return TOP.replace('NAME','self_modify_collision').replace('BODY',body),rom_for('self_modify_collision',words)

def main():
    before,pattern=snapshot()
    tb,rom=isa_case()
    results=[run_case('isa_directed',tb,rom,pattern,v) for v in (0,1)]
    tb,rom=collision_case()
    results.append(run_case('self_modify_collision',tb,rom,pattern,1))
    assert all(sha(Path(path))==expected for path,expected in before.items())
    (OUT/'extended_result.json').write_text(json.dumps({'production_unchanged':True,'cases':results},indent=2)+'\n')

if __name__=='__main__':main()
